﻿/*------------*\
  DESCRIPTION 
\*------------*/

This resource pack is a module for Pyrolusite's GregTech Alternate Textures.
Request from mr10movie for an unrealisticly orange bronze.

Put it above PGTAT in your resource pack loading order.

/*-----------*\
  LEGAL STUFF  
\*-----------*/

This Resource Pack is under a Creative Commons License - Attribution, Non Commercial, Share Alike 4.0 International - which means you can do whatever you want with it as long as it's not used for commercial purposes, and in case you make something public with it - ie modifying some parts and release it as your own alternative on MCF, Planet Minecraft or whatever - crediting my work and using the same license I used here.
More info here : http://creativecommons.org/licenses/by-nc-sa/4.0/deed.en

